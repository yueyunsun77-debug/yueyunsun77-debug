from pathlib import Path
import re,json,hashlib,subprocess,textwrap,html,sys
Q=lambda s:json.dumps(s,ensure_ascii=False)
TITLES={'3.3.1.2':'空调制热','3.3.1.6':'自动空调模式','3.3.1.9':'前后风窗除霜／除雾'}
# Labels summarize guards for readability; exact expressions are retained in the mapping.
LABELS={
'3.3.1.2':['停止请求','无停止请求','全部使能条件满足','任一使能条件不满足','标定有效','标定无效','温度 ≥ 断开上限','温度 < 断开上限','原保护已激活','原保护未激活','温度 ≤ 恢复阈值','温度 > 恢复阈值'],
'3.3.1.6':['停止请求','无停止请求','AUTO激活','AUTO未激活','温度操作','循环操作','风量操作','送风模式操作','前除霜操作','AC操作','重复AUTO操作','无操作变化'],
'3.3.1.9':['停止请求','无停止请求','前除霜或前除雾','后风窗或未解析请求','环境请求除湿','环境未请求除湿','SOC>10 或（SOC<10 且前除霜）','SOC<10 且非前除霜','SOC=10（边界待确认）']}
def render(root,n):
 p=root/'需求活动图'/(n+'-需求活动图.sysml');s=p.read_text()
 # Ignore documentation when extracting syntax.
 syntax=re.sub(r'/\*.*?\*/','',s,flags=re.S)
 declarations=re.findall(r"\b(action|decide|merge|fork|join)\s+'([^']+)'",syntax)
 assert declarations[0]==('action','行为评估流程')
 nodes=declarations[1:];assert len({x[1] for x in nodes})==len(nodes)
 edges=[]
 for m in re.finditer(r"\bfirst\s+(start|'[^']+')\s+(?:if\s+(.+?)\s+)?then\s+(done|'[^']+')\s*;",syntax):
  a,g,b=m.groups();edges.append({'source':a.strip("'"),'target':b.strip("'"),'guard':g})
 assert len(edges)==len(re.findall(r'\bfirst\b',syntax))
 assert {e['source'] for e in edges}|{e['target'] for e in edges}=={name for _,name in nodes}|{'start','done'}
 guarded=[e for e in edges if e['guard'] is not None];assert len(guarded)==len(LABELS[n])
 for i,(e,label) in enumerate(zip(guarded,LABELS[n]),1):e.update(guard_id=f'G{i:02}',display_guard=label)
 ids={name:'N'+str(i) for i,(_,name) in enumerate(nodes)};ids.update(start='START',done='DONE')
 lines=['digraph G {','graph [rankdir=TB,bgcolor="#F5F8FC",fontname="Noto Sans CJK SC",fontsize=22,labelloc=t,pad=.35,nodesep=.45,ranksep=.68,splines=polyline,concentrate=false,dpi=140,label='+Q(n+' '+TITLES[n]+' · 代码对应活动图')+'];','node [shape=box,style="rounded,filled",fillcolor="#E3EFF9",color="#65839D",fontcolor="#203F56",fontname="Noto Sans CJK SC",fontsize=16,penwidth=1.1,margin=".18,.14"];','edge [color="#65839D",fontcolor="#203F56",fontname="Noto Sans CJK SC",fontsize=12,arrowsize=.65,penwidth=1.1];','START [shape=circle,width=.14,height=.14,fixedsize=true,label="",fillcolor="#203F56"];','DONE [shape=doublecircle,width=.19,height=.19,fixedsize=true,label="",fillcolor="#203F56"];']
 main_names={'获取本周期快照','是否继续评估','判定全部加热许可','使能条件判断','标定有效性判断','过温判断','保护记忆判断','恢复条件判断','合并控制结果','反馈电加热运行状态','自动模式判断','获取自动温控输入','调节座舱温度请求','协调自动温控请求','用户操作判断','合并模式结果','反馈自动与空调状态','接收风窗请求','风窗请求判断','处理前风窗控制模式','并行配置风窗参数','汇合风窗参数','仲裁热管理能力请求','环境除湿判断','低电量许可判断','合并制冷决定','合并风窗路径','反馈风窗与空调状态'}
 for kind,name in nodes:
  if kind in ['fork','join']:
   attrs='shape=rect,style=filled,fillcolor="#203F56",height=.055,width=5.5,fixedsize=true,label="",xlabel='+Q(name)
  else:
   label='\n'.join(textwrap.wrap(name,14))
   attrs='label='+Q(label)
   if kind in ['decide','merge']:attrs+=',shape=diamond,style=filled,fillcolor="#FFF0C9",fontsize=14,margin=".08,.06"'
  if name in main_names:attrs+=',group=main'
  lines.append(ids[name]+' ['+attrs+'];')
 rendered=[]
 for i,e in enumerate(edges,1):
  attrs=['id='+Q('E'+str(i))]
  if e['source'] in main_names and e['target'] in main_names:attrs.append('weight=100')
  if e.get('guard_id') and e['target'].startswith('合并'):attrs+=['constraint=false','weight=0']
  if e['target']=='done':attrs.append('constraint=false')
  if not e.get('guard_id') and not (e['source'].startswith('反馈')):attrs.append('weight=10')
  if e.get('guard_id'):attrs.append('label='+Q(e['guard_id']+' '+e['display_guard']))
  if e['source'].startswith('反馈') and e['target']=='获取本周期快照':attrs+=['constraint=false','style=dashed','tailport=e','headport=e']
  lines.append(ids[e['source']]+' -> '+ids[e['target']]+' ['+','.join(attrs)+'];')
  rendered.append((e['source'],e['target'],e['guard']))
 assert rendered==[(e['source'],e['target'],e['guard']) for e in edges]
 if n=='3.3.1.6':
  group=['更新温度并保持AUTO','保持AUTO循环操作','退出AUTO并保留其他自动项','切换至前除霜模式','处理AC关闭与Close反馈','记录重复AUTO语义缺口','保持当前自动控制']
  lines.append('{rank=same; '+';'.join(ids[x] for x in group)+';}')
 if n=='3.3.1.9':
  group=['请求风窗送风模式','请求最大送风量','请求来源规定的外循环','保持当前温度设定']
  lines.append('{rank=same; '+';'.join(ids[x] for x in group)+';}')
 note='按本目录SysML提取全部节点及first/if/then连线；未增删、合并动作或控制节点。\nG编号对应《图码对应清单.json》的完整守卫表达式；虚线保留代码中的下一周期回边。'
 if n=='3.3.1.2':note+='\n全部使能条件：制热请求、送风开启、目标温度>舱温、高压可用、无故障、SOC>10。'
 lines+=['NOTE [shape=note,fontsize=11,fillcolor="#F5F8FC",label='+Q(note)+'];',ids[[name for kind,name in nodes if name.startswith('反馈')][0]]+' -> NOTE [style=invis,weight=10];','}']
 dot=p.with_suffix('.dot');dot.write_text('\n'.join(lines))
 for ext in ['png','svg']:subprocess.run(['dot','-T'+ext,str(dot),'-o',str(p.with_suffix('.'+ext))],check=True,capture_output=True)
 return {'model':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nodes':[{'kind':k,'name':v} for k,v in nodes],'edges':edges,'counts':{k:sum(t==k for t,_ in nodes) for k in ['action','decide','merge','fork','join']}|{'edges':len(edges)},'checked':'全部声明节点及全部first/if/then语句逐项映射，守卫原文保留。'}
if __name__=='__main__':
 root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
 result=[render(root,n) for n in TITLES]
 (root/'修改说明与检查/图码对应清单.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 for r in result:print(r['model'],r['counts'])
